TestGem::TEST_PLUGIN_EXCEPTION = :loaded
raise Exception.new('boom')